#include "DrawCommon.h"

ConstBufferDataMaterial Material::GetConstBufferMaterial()
{
    return ConstBufferDataMaterial();
}
