#pragma once
class IndexBuffer
{
};

